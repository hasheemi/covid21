export function getPersen(angka, jumlah) {
  return Math.round((angka / jumlah) * 100);
}
