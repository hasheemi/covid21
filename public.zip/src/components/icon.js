import React from "react";

export default function icon(props) {
  return (
    <div className="map-icon">
      <img src={props.image} alt="" />
    </div>
  );
}
